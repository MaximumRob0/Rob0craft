# -*- coding: utf-8 -*-
"""
Rob0craft - ПОЛНАЯ ВЕРСИЯ С МЕНЮ И БЫСТРЫМИ КРИПЕРАМИ
"""

import sys
import os
import random
import math
import subprocess

# ========== PYGAME МЕНЮ ==========
def pygame_menu():
    import pygame
    pygame.init()
    
    WIDTH, HEIGHT = 800, 600
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Rob0craft")
    clock = pygame.time.Clock()
    
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    GRAY = (100, 100, 100)
    GREEN = (0, 255, 0)
    YELLOW = (255, 255, 0)
    
    try:
        font_title = pygame.font.Font(None, 72)
        font_button = pygame.font.Font(None, 36)
        font_small = pygame.font.Font(None, 20)
    except:
        font_title = pygame.font.SysFont("Arial", 72)
        font_button = pygame.font.SysFont("Arial", 36)
        font_small = pygame.font.SysFont("Arial", 20)
    
    TEXTUREPACKS_DIR = "texturepacks"
    packs = ["default"]
    if os.path.exists(TEXTUREPACKS_DIR):
        for item in os.listdir(TEXTUREPACKS_DIR):
            if os.path.isdir(os.path.join(TEXTUREPACKS_DIR, item)):
                if item not in packs:
                    packs.append(item)
    
    current_pack_index = 0
    selected_pack = packs[current_pack_index]
    
    mode = "main"
    selected = 0
    
    buttons = [
        {"rect": pygame.Rect(WIDTH//2 - 150, 200, 300, 50), "text": "НОВЫЙ МИР", "action": "new"},
        {"rect": pygame.Rect(WIDTH//2 - 150, 270, 300, 50), "text": "ВЫБОР ТЕКСТУРПАКА", "action": "pack_select"},
        {"rect": pygame.Rect(WIDTH//2 - 150, 340, 300, 50), "text": "ВЫХОД", "action": "quit"}
    ]
    
    running = True
    result = None
    
    while running:
        screen.fill(BLACK)
        
        for i in range(100):
            pygame.draw.circle(screen, (50, 50, 50), (random.randint(0, WIDTH), random.randint(0, HEIGHT//2)), 1)
        
        title = font_title.render("Rob0craft", True, YELLOW)
        title_rect = title.get_rect(center=(WIDTH//2, 80))
        screen.blit(title, title_rect)
        
        if mode == "main":
            for i, btn in enumerate(buttons):
                color = GREEN if i == selected else GRAY
                pygame.draw.rect(screen, color, btn["rect"])
                pygame.draw.rect(screen, WHITE, btn["rect"], 2)
                
                text = font_button.render(btn["text"], True, WHITE)
                text_rect = text.get_rect(center=(btn["rect"].centerx, btn["rect"].centery))
                screen.blit(text, text_rect)
            
            pack_info = font_small.render(f"Текстурпак: {selected_pack}", True, GRAY)
            screen.blit(pack_info, (10, HEIGHT - 25))
            
            footer = font_small.render("Управление: СТРЕЛКИ / ENTER", True, GRAY)
            footer_rect = footer.get_rect(center=(WIDTH//2, HEIGHT - 25))
            screen.blit(footer, footer_rect)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    result = "quit"
                
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        selected = (selected - 1) % len(buttons)
                    elif event.key == pygame.K_DOWN:
                        selected = (selected + 1) % len(buttons)
                    elif event.key == pygame.K_RETURN:
                        if buttons[selected]["action"] == "new":
                            result = ("new", selected_pack)
                            running = False
                        elif buttons[selected]["action"] == "pack_select":
                            mode = "pack_select"
                            selected = 0
                        elif buttons[selected]["action"] == "quit":
                            result = "quit"
                            running = False
                
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()
                    for i, btn in enumerate(buttons):
                        if btn["rect"].collidepoint(mx, my):
                            if btn["action"] == "new":
                                result = ("new", selected_pack)
                                running = False
                            elif btn["action"] == "pack_select":
                                mode = "pack_select"
                                selected = 0
                            elif btn["action"] == "quit":
                                result = "quit"
                                running = False
        
        elif mode == "pack_select":
            title2 = font_button.render("ВЫБОР ТЕКСТУРПАКА", True, GREEN)
            title2_rect = title2.get_rect(center=(WIDTH//2, 160))
            screen.blit(title2, title2_rect)
            
            for i, pack in enumerate(packs):
                y = 230 + i * 40
                color = GREEN if i == selected else WHITE
                text = font_small.render(pack, True, color)
                text_rect = text.get_rect(center=(WIDTH//2, y))
                screen.blit(text, text_rect)
            
            back_rect = pygame.Rect(WIDTH//2 - 80, 450, 160, 40)
            pygame.draw.rect(screen, GRAY, back_rect)
            pygame.draw.rect(screen, WHITE, back_rect, 2)
            back_text = font_small.render("НАЗАД", True, WHITE)
            back_text_rect = back_text.get_rect(center=(back_rect.centerx, back_rect.centery))
            screen.blit(back_text, back_text_rect)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    result = "quit"
                
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        selected = (selected - 1) % len(packs)
                    elif event.key == pygame.K_DOWN:
                        selected = (selected + 1) % len(packs)
                    elif event.key == pygame.K_RETURN:
                        selected_pack = packs[selected]
                        mode = "main"
                        selected = 0
                    elif event.key == pygame.K_ESCAPE:
                        mode = "main"
                        selected = 0
                
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()
                    if back_rect.collidepoint(mx, my):
                        mode = "main"
                        selected = 0
                    else:
                        for i, pack in enumerate(packs):
                            y = 230 + i * 40
                            if WIDTH//2 - 100 <= mx <= WIDTH//2 + 100 and y - 15 <= my <= y + 15:
                                selected_pack = pack
                                mode = "main"
                                selected = 0
        
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()
    return result

# ========== ИГРА ==========
def run_game(texture_pack):
    GAME_CODE = f'''
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from PIL import Image
import random
import math
import os

app = Ursina()

# ---------- НАСТРОЙКИ ----------
window.title = 'Rob0craft'
window.fullscreen = False
window.exit_button.visible = True
window.fps_counter.enabled = True

# ---------- ТЕКСТУРПАКИ ----------
TEXTUREPACKS_DIR = "texturepacks"
CURRENT_TEXTURE_PACK = "{texture_pack}"

if not os.path.exists(TEXTUREPACKS_DIR):
    os.makedirs(TEXTUREPACKS_DIR)

default_pack_path = os.path.join(TEXTUREPACKS_DIR, "default")
if not os.path.exists(default_pack_path):
    os.makedirs(default_pack_path)

textures_cache = {{}}

def load_texture_from_pack(tex_name):
    pack_path = os.path.join(TEXTUREPACKS_DIR, CURRENT_TEXTURE_PACK, f"{{tex_name}}.png")
    if os.path.exists(pack_path):
        try:
            return Texture(pack_path)
        except:
            pass
    
    default_path = os.path.join(TEXTUREPACKS_DIR, "default", f"{{tex_name}}.png")
    if os.path.exists(default_path):
        try:
            return Texture(default_path)
        except:
            pass
    
    return None

def reload_textures():
    global textures_cache
    tex_list = ["grass", "stone", "oak", "leaves", "dirt", "bedrock", "creeper", 
                "diamond_ore", "iron_ore", "gold_ore", "emerald_ore", "coal_ore"]
    for tex_name in tex_list:
        textures_cache[tex_name] = load_texture_from_pack(tex_name)

reload_textures()

# ---------- НЕБО ----------
Sky(color=color.rgb(135, 206, 235))

# ---------- КЛАССЫ БЛОКОВ ----------
class GrassBlock(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("grass")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(34,139,34), position=pos, collider='box')

class StoneBlock(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("stone")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(128,128,128), position=pos, collider='box')

class OakBlock(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("oak")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(101,67,33), position=pos, collider='box')

class LeavesBlock(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("leaves")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(34,139,34), position=pos, collider='box')

class DirtBlock(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("dirt")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(101,67,33), position=pos, collider='box')

class BedrockBlock(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("bedrock")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(40,40,45), position=pos, collider='box')

class DiamondOre(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("diamond_ore")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(80,180,200), position=pos, collider='box')

class IronOre(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("iron_ore")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(180,160,120), position=pos, collider='box')

class GoldOre(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("gold_ore")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(220,200,80), position=pos, collider='box')

class EmeraldOre(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("emerald_ore")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(80,200,80), position=pos, collider='box')

class CoalOre(Entity):
    def __init__(self, pos):
        tex = textures_cache.get("coal_ore")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(40,40,40), position=pos, collider='box')

# ---------- БЫСТРЫЙ КРИПЕР С ОТБРОСОМ ----------
class Creeper(Entity):
    def __init__(self, pos, player_ref):
        tex = textures_cache.get("creeper")
        if tex:
            super().__init__(model='cube', texture=tex, position=pos, scale=0.8, collider='box')
        else:
            super().__init__(model='cube', color=color.rgb(68,88,52), position=pos, scale=0.8, collider='box')
        self.player_ref = player_ref
        self.speed = 0.06
        self.fuse_time = 35
        self.fuse_counter = 0
        self.is_fuse_lit = False
        self.is_dead = False
        
    def update(self):
        if self.is_dead or not self.player_ref:
            return
        dx = self.player_ref.x - self.x
        dz = self.player_ref.z - self.z
        dist = math.hypot(dx, dz)
        
        if self.is_fuse_lit:
            self.fuse_counter += 1
            self.color = color.white if (self.fuse_counter // 5) % 2 == 0 else color.clear
            if self.fuse_counter >= self.fuse_time:
                self.explode()
            return
        
        if dist < 1.5:
            self.is_fuse_lit = True
            self.fuse_counter = self.fuse_time - 15
            print("💚 Крипер подошёл! SSSSSS!")
        elif dist < 5:
            self.is_fuse_lit = True
            print("💚 Крипер шипит! Убегай!")
        elif dist < 20 and dist > 0.5:
            self.x += (dx / dist) * self.speed
            self.z += (dz / dist) * self.speed
    
    def explode(self):
        if self.is_dead:
            return
        self.is_dead = True
        print("💥 БАХ! Крипер взорвался!")
        
        flash = Entity(model='cube', color=color.white, scale=3, position=self.position, alpha=1)
        flash.animate('alpha', 0, duration=0.3)
        destroy(flash, delay=0.3)
        
        if self.player_ref and math.hypot(self.x - self.player_ref.x, self.z - self.player_ref.z) < 3:
            angle = math.atan2(self.player_ref.z - self.z, self.player_ref.x - self.x)
            push_x = math.cos(angle) * 8
            push_z = math.sin(angle) * 8
            self.player_ref.x += push_x
            self.player_ref.z += push_z
            self.player_ref.y += 2
            print("💥 Тебя отбросило взрывом!")
        
        to_remove = []
        for b in blocks:
            bx, by, bz = b.position
            if abs(bx - self.x) <= 2 and abs(bz - self.z) <= 2 and -1 <= by <= 1:
                if not isinstance(b, BedrockBlock):
                    to_remove.append(b)
        for b in to_remove:
            if b in blocks:
                blocks.remove(b)
                destroy(b)
        
        if self in creepers:
            creepers.remove(self)
        destroy(self)

# ---------- СОЗДАНИЕ МИРА ----------
blocks = []
creepers = []
spawn_timer = 0
spawn_positions = []

def create_tree(x, z):
    trunk_height = random.randint(3, 4)
    for y in range(trunk_height):
        blocks.append(OakBlock((x, y + 1, z)))
    tree_top_y = trunk_height + 1
    for xx in range(-2, 3):
        for zz in range(-2, 3):
            if abs(xx) == 2 and abs(zz) == 2:
                continue
            if xx == 0 and zz == 0:
                continue
            blocks.append(LeavesBlock((x + xx, tree_top_y, z + zz)))
    for xx in range(-1, 2):
        for zz in range(-1, 2):
            if xx == 0 and zz == 0:
                blocks.append(LeavesBlock((x + xx, tree_top_y + 1, z + zz)))
            else:
                blocks.append(LeavesBlock((x + xx, tree_top_y + 1, z + zz)))
    blocks.append(LeavesBlock((x, tree_top_y + 2, z)))

print("🌍 Создаю мир...")

for x in range(-12, 13):
    for z in range(-12, 13):
        blocks.append(GrassBlock((x, 0, z)))
        blocks.append(DirtBlock((x, -1, z)))
        for y in (-2, -3):
            r = random.random()
            if r < 0.03:
                blocks.append(DiamondOre((x, y, z)))
            elif r < 0.07:
                blocks.append(EmeraldOre((x, y, z)))
            elif r < 0.12:
                blocks.append(GoldOre((x, y, z)))
            elif r < 0.20:
                blocks.append(IronOre((x, y, z)))
            elif r < 0.35:
                blocks.append(CoalOre((x, y, z)))
            else:
                blocks.append(StoneBlock((x, y, z)))
        blocks.append(BedrockBlock((x, -4, z)))
        
        if abs(x) > 3 and abs(z) > 3:
            spawn_positions.append((x, 0.5, z))

for _ in range(15):
    tx = random.randint(-10, 10)
    tz = random.randint(-10, 10)
    if abs(tx) < 3 and abs(tz) < 3:
        continue
    for dx in range(-2, 3):
        for dz in range(-2, 3):
            pos = (tx + dx, 0.5, tz + dz)
            if pos in spawn_positions:
                spawn_positions.remove(pos)
    create_tree(tx, tz)

print(f"✅ Создано {{len(blocks)}} блоков")
print(f"📍 Безопасных мест для криперов: {{len(spawn_positions)}}")

# ---------- ИГРОК ----------
player = FirstPersonController(
    speed=12,
    jump_height=2,
    position=(0, 2, 0),
    mouse_sensitivity=Vec2(100, 100)
)
player.visible = False
player.collider = 'box'

# ---------- ОСВЕЩЕНИЕ ----------
DirectionalLight(y=10, rotation=(45, -30, 0), intensity=1.5)
AmbientLight(color=color.rgb(80, 80, 80))

# ---------- ИНТЕРФЕЙС ----------
info_text = Text(text='★ Rob0craft ★', position=(-0.8,0.48), scale=1.1, background=True, color=color.yellow)
pack_text = Text(text='Текстурпак: ' + CURRENT_TEXTURE_PACK, position=(-0.8,0.43), scale=0.6, background=True, color=color.lime)
coords_text = Text(text='', position=(-0.8,0.38), scale=1, background=True)
creeper_text = Text(text='💚 Криперов: 0', position=(-0.8,0.33), scale=0.8, background=True, color=color.red)
controls_text = Text(text='WASD - ходьба | Мышь - поворот | ЛКМ - ломать | ПКМ - ставить | 1-5 - блоки | R - вернуться | ESC - выход', position=(-0.8,-0.45), scale=0.7, background=True)

# ---------- ПЕРЕМЕННЫЕ ----------
current_block_type = 'grass'
block_distance = 4
spawn_timer = 0
SPAWN_INTERVAL = 30

# ---------- ФУНКЦИИ ----------
def get_target_block():
    origin = player.position + Vec3(0, 1.5, 0)
    hit = raycast(origin, camera.forward, distance=block_distance, ignore=(player,))
    if hit.hit:
        return hit.entity, hit.point, hit.normal
    return None, None, None

def break_block():
    block, _, _ = get_target_block()
    if block and block in blocks:
        if isinstance(block, BedrockBlock):
            print("💀 Бедрок нельзя сломать!")
            return
        if isinstance(block, DiamondOre): print("💎 Алмазная руда!")
        elif isinstance(block, IronOre): print("⚙️ Железная руда!")
        elif isinstance(block, GoldOre): print("🟡 Золотая руда!")
        elif isinstance(block, EmeraldOre): print("💚 Изумрудная руда!")
        elif isinstance(block, CoalOre): print("⚫ Угольная руда!")
        else: print("🔨 Блок сломан!")
        blocks.remove(block)
        destroy(block)

def place_block():
    global current_block_type
    block, _, norm = get_target_block()
    if not block or not norm:
        return
    new_pos = (int(block.position.x + norm.x), int(block.position.y + norm.y), int(block.position.z + norm.z))
    
    for b in blocks:
        if b.position == new_pos:
            return
    
    if current_block_type == 'grass':
        blocks.append(GrassBlock(new_pos))
    elif current_block_type == 'stone':
        blocks.append(StoneBlock(new_pos))
    elif current_block_type == 'wood':
        blocks.append(OakBlock(new_pos))
    elif current_block_type == 'leaves':
        blocks.append(LeavesBlock(new_pos))
    elif current_block_type == 'dirt':
        blocks.append(DirtBlock(new_pos))
    print(f"✅ Поставлен {{current_block_type}}")

def change_block(btype):
    global current_block_type
    current_block_type = btype
    names = {{'grass':'ТРАВА 🌿','stone':'КАМЕНЬ 🪨','wood':'ДУБ 🪵','leaves':'ЛИСТВА 🍃','dirt':'ЗЕМЛЯ 🟫'}}
    print(f"✅ Выбран блок: {{names.get(btype, btype)}}")

def spawn_creeper():
    if not player or not spawn_positions:
        return
    
    far_positions = []
    for pos in spawn_positions:
        dist = math.hypot(pos[0] - player.x, pos[2] - player.z)
        if dist > 4:
            far_positions.append(pos)
    
    if not far_positions:
        return
    
    spawn_pos = random.choice(far_positions)
    x, y, z = spawn_pos
    
    for c in creepers:
        if math.hypot(c.x - x, c.z - z) < 2:
            return
    
    creepers.append(Creeper((x, y, z), player))
    print("💚 Появился крипер!")

def input(key):
    if key in ('escape', 'q'):
        application.quit()
    if key == 'r':
        player.position = (0, 2, 0)
        player.rotation = (0, 0, 0)
        print("📍 Возврат на старт!")
    if key == 'left mouse down':
        break_block()
    if key == 'right mouse down':
        place_block()
    if key == '1':
        change_block('grass')
    if key == '2':
        change_block('stone')
    if key == '3':
        change_block('wood')
    if key == '4':
        change_block('leaves')
    if key == '5':
        change_block('dirt')
    if key == '6':
        change_block('diamond')
    if key == '7':
        change_block('iron')
    if key == '8':
        change_block('gold')
    if key == '9':
        change_block('emerald')
    if key == '0':
        change_block('coal')

def update():
    global spawn_timer
    coords_text.text = f'X={{int(player.x)}} Y={{int(player.y)}} Z={{int(player.z)}}'
    creeper_text.text = f'💚 Криперов: {{len(creepers)}}'
    
    if player.y < -5:
        player.position = (0, 2, 0)
    
    spawn_timer += time.dt
    if spawn_timer >= SPAWN_INTERVAL:
        spawn_timer = 0
        spawn_creeper()
    
    for c in creepers[:]:
        c.update()

print("""
╔════════════════════════════════════════════╗
║              Rob0craft                     ║
╠════════════════════════════════════════════╣
║  🎮 УПРАВЛЕНИЕ:                           ║
║  • WASD - ходьба                          ║
║  • Мышь - поворот камеры                  ║
║  • ЛКМ - ломать блок                      ║
║  • ПКМ - ставить блок                     ║
║  • 1-5 - выбор блоков                     ║
║  • R - вернуться на старт                 ║
║  • ESC - выход                            ║
╠════════════════════════════════════════════╣
║  🌤️ НЕБО RGB(135, 206, 235)               ║
║  💨 КРИПЕРЫ БЫСТРЕЕ И ОТБРАСЫВАЮТ!         ║
╚════════════════════════════════════════════╝
""")

app.run()
'''
    
    print(f"🎮 Запуск игры с текстурпаком: {texture_pack}")
    subprocess.run([sys.executable, "-c", GAME_CODE])

# ========== ГЛАВНАЯ ФУНКЦИЯ ==========
def main():
    while True:
        result = pygame_menu()
        if result is None:
            continue
        elif result == "quit":
            print("👋 Выход из игры...")
            break
        elif isinstance(result, tuple) and result[0] == "new":
            run_game(result[1])

if __name__ == "__main__":
    main()
